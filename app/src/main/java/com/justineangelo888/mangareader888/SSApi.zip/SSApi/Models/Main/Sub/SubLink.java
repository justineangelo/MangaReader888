package com.justineangelo888.mangareader888.SSApi.Models.Main.Sub;

import com.justineangelo888.mangareader888.SSApi.Models.Main.Link;

    /**
     * Created by justine on 21/04/16.
     */
    public class SubLink extends Link {
        public static SubLink init() {
            return new SubLink();
        }
    }